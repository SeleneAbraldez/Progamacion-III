<?php

interface IParte3
{
    public function Modificar($id, $ovni);
    public function Eliminar($id);
}

?>